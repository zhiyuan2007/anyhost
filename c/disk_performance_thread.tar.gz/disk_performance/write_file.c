#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <stdint.h>
#include <signal.h>
#include <pthread.h>
#include <stdbool.h>
#define UP_LIMIT 2000000
#define OUTPUT_INTERVAL  100000
#define DEFAULT_FILE "file_for_wirte_test.txt"
uint32_t total_count = 0;
unsigned long total_byte = 0;
bool run = true;
pthread_t tid;
long get_time()
{
    struct timeval t_start;
    gettimeofday(&t_start, NULL);
    long start = ((long)t_start.tv_sec)*1000+(long)t_start.tv_usec/1000;
    printf("current time: %ld ms\n", start);
    return start;
}

void signal_cb(int event)
{
    if (event == SIGINT || event == SIGTERM)
    {
        printf("recevice terminated signal\n");
        run = false;
        exit(0);
        pthread_cancel(tid);
    }
}

void *speed_worker(void *data)
{
    long t1 = get_time();
    uint32_t v1 = total_count;
    uint32_t lb1 = total_byte;
    while(run)
    {
        sleep(3);
        uint32_t lb2 = total_byte;
        uint32_t v2 = total_count;
        long t2 = get_time();
        double time_cost = (t2 - t1)*1.0/1000.0;
        double speed = (v2 - v1)/time_cost;
        uint32_t diff = lb2 -lb1;
        printf("speed: %0.3fM/s|%0.3fK/s|%0.3fline/s\n",(diff*1.0/1048576)/time_cost, (diff*1.0/1024)/time_cost, speed);
        v1 = v2;
        t1 = t2;
        lb1 = lb2;
    }
}
void write_log_to_file(const char *filename)
{

    FILE *fp = fopen(filename, "w");
    if (fp == NULL)
    {
        printf("open file %s failed", filename);
        return;
    }
    const char *log_info = "11-Mar-2014 10:40:54.177 client 202.173.9.29 58931: view default: wh.bs.ourgame.com IN A SERVFAIL + NS E NT D NC";
    for (;run;total_count++)
    {
        total_byte += fprintf(fp, "%s no. %u\n", log_info, total_count);
        fflush(fp);
    }
    fclose(fp);
}
int main(int argc, char *argv[])
{
    if (argc == 2 && strcmp(argv[1], "-h") == 0)
    {
        printf("usage: ./performance\n");
    }
    else
    {
        signal(SIGINT, signal_cb);
        signal(SIGTERM, signal_cb);

        pthread_create(&tid, NULL, speed_worker, NULL);
        write_log_to_file(DEFAULT_FILE);
    }
    return 0;
}
