tar zxvf setuptools-0.6c11.tar.gz
cd setuptools-0.6c11
python setup.py install
cd ..
tar zxvf scapy-latest.tar.gz
cd scapy-2.1.0
python setup.py install
